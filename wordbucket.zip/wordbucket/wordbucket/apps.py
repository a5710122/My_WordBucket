from django.apps import AppConfig


class WordbucketConfig(AppConfig):
    name = 'wordbucket'
